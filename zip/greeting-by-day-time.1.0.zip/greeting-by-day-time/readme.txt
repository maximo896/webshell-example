=== Say hello ===
Contributors: haghs
Donate link: https://www.paypal.com/donate/?hosted_button_id=TMLCHZ46Y6HRU
Tags: Greet your website visitors by time of day
Requires at least: 6.9
Tested up to: 6.9
Stable tag: 1.0
Requires PHP: 8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Greet your website visitors by time of day with shortcode on pages or posts.

== Description ==
 
This plugin allows you to use the shortcode to address your website visitors as follows: good morning, good day and good evening. 

Supported languages


Arabic use [mrhban_ae]
________________________

Chinese use [nihao_chn]
________________________

English use [hello_en]
________________________

Farsi use [dorud_irn]
________________________

French use [bonjour_fr]
________________________

German use [hallo_de]
________________________

Greek use [chairete_grc]
________________________

Irish use [heileo_ir]
________________________

Italian use [ciao_it]
________________________

Polish use [czesc_pol]
________________________

Spanish use [hola_sp]
________________________



== Frequently Asked Questions ==

=How can i use it?=

Just activate the plugin and put your languages shortcode where you want the text to display.
= A question that someone might have =

== Screenshots ==

== Changelog ==

= 1.0 =
No change since the previous version.


== Upgrade Notice ==
No Upgrade

